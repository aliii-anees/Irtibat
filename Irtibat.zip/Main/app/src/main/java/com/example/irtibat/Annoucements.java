package com.example.irtibat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class Annoucements extends AppCompatActivity {

    Button homeAnn, profAnn;
    FirebaseUser user;
    FirebaseAuth auth;
    Button btn1, btn2, btn3, btn4, btn5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_annoucements);

        btn1 = findViewById(R.id.Annbtn1);
        btn2 = findViewById(R.id.Annbtn2);
        btn3 = findViewById(R.id.Annbtn3);
        btn4 = findViewById(R.id.Annbtn4);

        homeAnn = findViewById(R.id.button3);
        profAnn = findViewById(R.id.button5);

        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        if (user == null) {
            Intent intent = new Intent(getApplicationContext(), Login.class);
            startActivity(intent);
            finish();
        }

        homeAnn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Annoucements.this, MainActivity.class);
                startActivity(intent);
            }
        });

        profAnn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(Annoucements.this, CUser.class);
                startActivity(intent1);
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Annoucements.this, HomeBtn1.class);
                startActivity(intent);
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Annoucements.this, HomeBtn2.class);
                startActivity(intent);
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Annoucements.this, HomeBtn3.class);
                startActivity(intent);
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Annoucements.this, HomeBtn4.class);
                startActivity(intent);
            }
        });


    }
}