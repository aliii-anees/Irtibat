package com.example.irtibat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class BLogin extends AppCompatActivity {

    Button blgn, reglinkb;
    TextView emailEditb, passwordEditb, cLog;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_blogin);

            blgn = findViewById(R.id.login2);
            reglinkb = findViewById(R.id.regbtn2);

            mAuth = FirebaseAuth.getInstance();
            fStore = FirebaseFirestore.getInstance();

            emailEditb = findViewById(R.id.email2);
            passwordEditb = findViewById(R.id.Password2);
            cLog = findViewById(R.id.textView40);

            cLog.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent intent = new Intent(BLogin.this, Login.class);
                    startActivity(intent);
                    finish();

                }
            });

            reglinkb.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(BLogin.this, BReg.class);
                    startActivity(intent);
                }
            });


            blgn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Cemail, Cpassword;
                    Cemail = String.valueOf(emailEditb.getText());
                    Cpassword = String.valueOf(passwordEditb.getText());


                    if (TextUtils.isEmpty(Cemail)) {
                        Toast.makeText(BLogin.this, "Enter Email", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (TextUtils.isEmpty(Cpassword)) {
                        Toast.makeText(BLogin.this, "Enter Password", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    mAuth.signInWithEmailAndPassword(Cemail, Cpassword).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                        @Override
                        public void onSuccess(AuthResult authResult) {
                            Toast.makeText(BLogin.this, "Logged In!", Toast.LENGTH_SHORT).show();
                            checkUserAccessLevel(authResult.getUser().getUid());
                        }

                        private void checkUserAccessLevel(String uid) {

                            DocumentReference df = fStore.collection("Business").document(uid);
                            df.get().addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                                @Override
                                public void onSuccess(DocumentSnapshot documentSnapshot) {
                                    Log.d("TAG", "onSuccess: " + documentSnapshot.getData());

                                    if (documentSnapshot.getString("isBus") != null) {
                                        Intent intent = new Intent(BLogin.this, BHome.class);
                                        startActivity(intent);
                                        finish();
                                    }
                                }
                            });

                        }
                    }).addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(BLogin.this, "Login Failed", Toast.LENGTH_SHORT).show();
                        }
                    });

                }
            });

        }
}