package com.example.irtibat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.ktx.Firebase;

import java.util.HashMap;
import java.util.Map;

public class CReg extends AppCompatActivity {

    Button reg, back;
    EditText FirstNameEdit, LastNameEdit, emailEdit, passwordEdit, phoneEdit;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creg);

        reg = findViewById(R.id.regenter);
        back = findViewById(R.id.button15);

        mAuth = FirebaseAuth.getInstance();
        fStore = FirebaseFirestore.getInstance();

        FirstNameEdit = findViewById(R.id.FName);
        LastNameEdit = findViewById(R.id.LName);
        emailEdit = findViewById(R.id.Email);
        passwordEdit = findViewById(R.id.Password);
        phoneEdit = findViewById(R.id.number);

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email, password, first, last, phone;
                email = String.valueOf(emailEdit.getText());
                password = String.valueOf(passwordEdit.getText());
                first = String.valueOf(FirstNameEdit.getText());
                last = String.valueOf(LastNameEdit.getText());
                phone = String.valueOf(phoneEdit.getText());

                if (TextUtils.isEmpty(first)) {
                    Toast.makeText(CReg.this, "Enter First Name", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(last)) {
                    Toast.makeText(CReg.this, "Enter Last Name", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(email)) {
                    Toast.makeText(CReg.this, "Enter Email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(password)) {
                    Toast.makeText(CReg.this, "Enter Password", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(phone)) {
                    Toast.makeText(CReg.this, "Enter Phone Number", Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.createUserWithEmailAndPassword(email, password).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        Toast.makeText(CReg.this, "Account Created", Toast.LENGTH_SHORT).show();
                        DocumentReference df = fStore.collection("Users").document(user.getUid());
                        Map<String, Object> userInfo = new HashMap<>();

                        userInfo.put("First Name", FirstNameEdit.getText().toString());
                        userInfo.put("Last Name", LastNameEdit.getText().toString());
                        userInfo.put("Email", emailEdit.getText().toString());
                        userInfo.put("Password", passwordEdit.getText().toString());
                        userInfo.put("Phone Number", phoneEdit.getText().toString());
                        userInfo.put("isUser", "1");

                        df.set(userInfo);

                        Intent intent = new Intent(CReg.this, Login.class);
                        startActivity(intent);
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(CReg.this, "Error Creating Account", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(CReg.this, Login.class);
                startActivity(intent1);
            }
        });

    }
}