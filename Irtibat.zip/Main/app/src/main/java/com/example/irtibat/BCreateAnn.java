package com.example.irtibat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class BCreateAnn extends AppCompatActivity {

    Button bhomepg2, bprof2;
    Button createann;
    FirebaseFirestore fStore;
    FirebaseAuth mAuth;
    TextView EditTitle, EditDetail, EditLocation, Editdatetime, EditRequest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bcreate_ann);

        fStore = FirebaseFirestore.getInstance();

        createann = findViewById(R.id.buttonregann);

        EditTitle = findViewById(R.id.editTextTextPersonName);
        EditDetail= findViewById(R.id.editTextTextPersonName2);
        EditLocation = findViewById(R.id.editTextTextPersonName3);
        Editdatetime = findViewById(R.id.editTextTextPersonName4);
        EditRequest = findViewById(R.id.editTextTextPersonName5);

        bhomepg2 = findViewById(R.id.button80);
        bprof2 = findViewById(R.id.button82);

        bhomepg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BCreateAnn.this, BHome.class);
                startActivity(intent);
            }
        });

        bprof2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BCreateAnn.this, BProfile.class);
                startActivity(intent);
            }
        });

        createann.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String title = EditTitle.getText().toString();
                String details = EditDetail.getText().toString();
                String location = EditLocation.getText().toString();
                String datetime = Editdatetime.getText().toString();
                String request = EditRequest.getText().toString();

                if (TextUtils.isEmpty(title)) {
                    Toast.makeText(BCreateAnn.this, "Enter Event Title", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(details)) {
                    Toast.makeText(BCreateAnn.this, "Enter Event Details", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(location)) {
                    Toast.makeText(BCreateAnn.this, "Enter Event Location", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(datetime)) {
                    Toast.makeText(BCreateAnn.this, "Enter Date and Time", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(request)) {
                    Toast.makeText(BCreateAnn.this, "Enter Volunteer Request", Toast.LENGTH_SHORT).show();
                    return;
                }

                Toast.makeText(BCreateAnn.this, "Event Created", Toast.LENGTH_SHORT).show();
                DocumentReference df = fStore.collection("Events").document();
                Map<String, Object> eventinfo = new HashMap<>();

                eventinfo.put("Event Title", EditTitle.getText().toString());
                eventinfo.put("Event Details", EditDetail.getText().toString());
                eventinfo.put("Event Location", EditLocation.getText().toString());
                eventinfo.put("Event Date and Time", Editdatetime.getText().toString());
                eventinfo.put("Event Request", EditRequest.getText().toString());

                df.set(eventinfo);
            }
        });

    }
}