package com.example.irtibat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class BProfile extends AppCompatActivity {

    Button Bhomepg3, CAnn3;
    Button Blogout;
    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bprofile);

        mAuth = FirebaseAuth.getInstance();

        Bhomepg3 = (Button)findViewById(R.id.buttonBhome3);
        CAnn3 = (Button) findViewById(R.id.buttonCAnn3);

        Blogout = findViewById(R.id.button10);

        Bhomepg3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BProfile.this, BHome.class);
                startActivity(intent);
            }
        });

        CAnn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(BProfile.this, BCreateAnn.class);
                startActivity(intent);
            }
        });

        Blogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAuth.signOut();
                Intent intent = new Intent(BProfile.this, BLogin.class);
                startActivity(intent);
                finish();
            }
        });

    }
}