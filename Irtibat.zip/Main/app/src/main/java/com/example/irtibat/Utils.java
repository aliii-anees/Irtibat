package com.example.irtibat;

public class Utils {

    public static final String EMAIL = "irtibattest@gmail.com";

    public static  final String PASSWORD = "pantlhmffrxwsiob";

}
