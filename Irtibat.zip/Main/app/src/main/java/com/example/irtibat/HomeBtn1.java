package com.example.irtibat;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

public class HomeBtn1 extends AppCompatActivity {

    Button Homepg1, Annpg1, Profpg1;
    Button regevent;
    FirebaseFirestore fStore;
    FirebaseAuth mAuth;
    String email;
    String mSubject, mMessage;
    TextView Hyperlink1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_btn1);

        Homepg1 = findViewById(R.id.button3);
        Annpg1 = findViewById(R.id.button4);
        Profpg1 = findViewById(R.id.button5);
        regevent = findViewById(R.id.regbtn4);

        mAuth = FirebaseAuth.getInstance();

        mSubject = "Event Registration";
        mMessage = "You are now registered for the event, please show this email to the crew to get your badge.";

        Homepg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeBtn1.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Annpg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeBtn1.this, Annoucements.class);
                startActivity(intent);
            }
        });

        Profpg1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(HomeBtn1.this, CUser.class);
                startActivity(intent1);
            }
        });

        Hyperlink1 = findViewById(R.id.textView24);
        Hyperlink1.setMovementMethod(LinkMovementMethod.getInstance());
        Hyperlink1.setLinkTextColor(Color.BLUE);

        regevent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userInfo();
                sendMail();


                Toast.makeText(HomeBtn1.this, "You have been registered", Toast.LENGTH_SHORT).show();
            }

            private void sendMail() {

                String mail = email;
                String subject = mSubject;
                String message = mMessage;

                JavaMailAPI JMAPI = new JavaMailAPI(HomeBtn1.this, mail, subject, message);
                JMAPI.execute();

            }

            private void userInfo() {
                FirebaseUser user = mAuth.getCurrentUser();

                if (user != null) {
                    email = user.getEmail();
                }
            }
        });


    }
}