    package com.example.irtibat;

    import androidx.appcompat.app.AppCompatActivity;

    import android.content.Intent;
    import android.graphics.Color;
    import android.os.Bundle;
    import android.text.method.LinkMovementMethod;
    import android.view.View;
    import android.widget.Button;
    import android.widget.TextView;
    import android.widget.Toast;

    import com.google.firebase.auth.FirebaseAuth;
    import com.google.firebase.auth.FirebaseUser;

    public class HomeBtn3 extends AppCompatActivity {

        Button Homepg3, Annpg3, Profpg3;
        Button regevent;
        FirebaseAuth mAuth;
        String email;
        String mSubject, mMessage;
        TextView Hyperlink3;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_home_btn3);

            Homepg3 = findViewById(R.id.button3);
            Annpg3 = findViewById(R.id.button4);
            Profpg3 = findViewById(R.id.button5);
            regevent = findViewById(R.id.button2);

            Homepg3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeBtn3.this, MainActivity.class);
                    startActivity(intent);
                }
            });

            Annpg3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(HomeBtn3.this, Annoucements.class);
                    startActivity(intent);
                }
            });

            Profpg3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent1 = new Intent(HomeBtn3.this, CUser.class);
                    startActivity(intent1);
                }
            });

            Hyperlink3 = findViewById(R.id.textView24);
            Hyperlink3.setMovementMethod(LinkMovementMethod.getInstance());
            Hyperlink3.setLinkTextColor(Color.BLUE);

            regevent.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    userInfo();
                    sendMail();


                    Toast.makeText(HomeBtn3.this, "You have been registered", Toast.LENGTH_SHORT).show();
                }

                private void sendMail() {

                    String mail = email;
                    String subject = mSubject;
                    String message = mMessage;

                    JavaMailAPI JMAPI = new JavaMailAPI(HomeBtn3.this, mail, subject, message);
                    JMAPI.execute();

                }

                private void userInfo() {
                    FirebaseUser user = mAuth.getCurrentUser();

                    if (user != null) {
                        email = user.getEmail();
                    }
                }
            });
        }
    }