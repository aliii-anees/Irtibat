package com.example.irtibat;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class BReg extends AppCompatActivity {

    Button Breg, back;
    TextView CName, CEmail, pass;
    FirebaseAuth mAuth;
    FirebaseFirestore fStore;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_breg);

        Breg = findViewById(R.id.breg);
        back = findViewById(R.id.button16);

        fStore = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();

        CName = findViewById(R.id.CompName);
        CEmail = findViewById(R.id.CompEmail);
        pass = findViewById(R.id.CompPass);

        Breg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String cName = CName.getText().toString();
                String cEmail = CEmail.getText().toString();
                String cPass = pass.getText().toString();

                if (TextUtils.isEmpty(cName)) {
                    Toast.makeText(BReg.this, "Enter Company Name", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(cEmail)) {
                    Toast.makeText(BReg.this, "Enter Company Email", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (TextUtils.isEmpty(cPass)) {
                    Toast.makeText(BReg.this, "Enter Password", Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.createUserWithEmailAndPassword(cEmail, cPass).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {

                        FirebaseUser bus = mAuth.getCurrentUser();
                        Toast.makeText(BReg.this, "Account Created", Toast.LENGTH_SHORT).show();
                        DocumentReference df = fStore.collection("Business").document(bus.getUid());
                        Map<String, Object> busInfo = new HashMap<>();

                        busInfo.put("Company Name", CName.getText().toString());
                        busInfo.put("Company Email", CEmail.getText().toString());
                        busInfo.put("Company Password", pass.getText().toString());
                        busInfo.put("isBus", "1");

                        df.set(busInfo);
                        Intent intent = new Intent(BReg.this, BLogin.class);
                        startActivity(intent);
                        finish();

                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(BReg.this, "Failed to Create Account", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(BReg.this, BLogin.class);
                startActivity(intent1);

            }
        });

    }
}