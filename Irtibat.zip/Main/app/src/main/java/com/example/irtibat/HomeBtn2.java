package com.example.irtibat;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class HomeBtn2 extends AppCompatActivity {

    Button Homepg2, Annpg2, Profpg2;
    Button regevent;
    String email;
    String mSubject, mMessage;
    FirebaseAuth mAuth;
    TextView Hyperlink2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_btn2);

        Homepg2 = findViewById(R.id.button3);
        Annpg2 = findViewById(R.id.button4);
        Profpg2 = findViewById(R.id.button5);
        regevent = findViewById(R.id.button2);


        Homepg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeBtn2.this, MainActivity.class);
                startActivity(intent);
            }
        });

        Annpg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(HomeBtn2.this, Annoucements.class);
                startActivity(intent);
            }
        });

        Profpg2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(HomeBtn2.this, CUser.class);
                startActivity(intent1);
            }
        });

        Hyperlink2 = findViewById(R.id.textView24);
        Hyperlink2.setMovementMethod(LinkMovementMethod.getInstance());
        Hyperlink2.setLinkTextColor(Color.BLUE);

        regevent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                userInfo();
                sendMail();


                Toast.makeText(HomeBtn2.this, "You have been registered", Toast.LENGTH_SHORT).show();
            }

            private void sendMail() {

                String mail = email;
                String subject = mSubject;
                String message = mMessage;

                JavaMailAPI JMAPI = new JavaMailAPI(HomeBtn2.this, mail, subject, message);
                JMAPI.execute();

            }

            private void userInfo() {
                FirebaseUser user = mAuth.getCurrentUser();

                if (user != null) {
                    email = user.getEmail();
                }
            }
        });

    }
}